package com.javatpoint;  
import javax.ejb.Remote;  
@Remote  
public interface StoreRemote {  
    /*boolean withdraw(int amount);  
    void deposit(int amount);  */  
    int getAmount();
    int cal(int quantity,int amount);
}  