package com.javatpoint;  

//import static java.lang.System.out;  
import static java.lang.System.out;
import javax.ejb.Stateful;
@Stateful(mappedName = "stateful123")  
public class Store implements StoreRemote {  
    private int amount=0;  
    private final int quantity=0; 
  /*  public boolean withdraw(int amount){  
        if(amount<=this.amount){  
            this.amount-=amount;  
            return true;  
        }else{  
            return false;  
        }  
    }  */
  /*  public void deposit(int amount){  
        this.amount+=amount;  
    }  */

    @Override
    public int getAmount(){  
        return amount;  
    }  
    public int cal(int quantity,int amount)
    {
        this.amount=amount*quantity;
  
        //System.out.println(amount);
        return 0;
    }

    public int pay(int quantity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int pay(int quantity, int amount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}  